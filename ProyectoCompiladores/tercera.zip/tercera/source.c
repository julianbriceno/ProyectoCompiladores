{
	int ma;
	float yer;
	char lin;
	{
		int uz;
		int ca[2][2][2];
		float te;
		{
			char gui[10];
			char jajaja[50];
			float jejeje[50][50];
		}
	}
	{
		char jojojo[10][100];
		float jujuju[5][5][5][5][5][5];
	}
}
